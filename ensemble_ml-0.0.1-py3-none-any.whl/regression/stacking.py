from . import *

from .main import Ensemble
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from collections import defaultdict


class Stacking(Ensemble):
    '''
    #* Stacking, also known as stacked generalization, 
    #* is an ensemble method where the models are combined
    #* using another machine learning algorithm
    #* The basic idea is to train machine learning algorithms
    #* with training dataset and then generate a new dataset
    #* with these models. Then this new dataset is used as 
    #* input for the combiner machine learning algorithm.
    #*
    #* Attributes
    #* ----------
    #*
    #* Methods
    #* ----------
    #*'''
    def __init__(
        self,
        base_estimators,
        meta_estimator,
    ):
        super().__init__(
            base_estimators=base_estimators,
            meta_estimator=meta_estimator
        )
        self.model = dict()


    

    #! Iteration incrementing of model has not been implemented yet
    #! Recursion for iterations??
    def make_model(
        self,
        X_raw: pd.core.frame.DataFrame, #* raw
        y: pd.core.frame.DataFrame,
        ct_transformers: list | None = None, #* to fill ColumnTransformer
        itr:int | None = None
        #? are chain predictions avaliable???
    ):  
        '''
        #* Method to initiate stadking model building
        #* The (result) output model may consists of iterations - versions of model 
        #* On the other hand each version of model may be one of two model types:
        #*  MultiOutput model
        #*  Chain model
        #* ! NOTE: all iteration are same type ! 
        #* Dependens on model type X-variable may be different 
        #* from feature to feature iterations (for chain type
        #* features increments sequentially)
        #* 
        #* Parameters
        #* ----------
        #*
        #* Raises
        #* ----------
        #*
        #* Returns
        #* ----------
        #*
        '''
        model_features = {}
        model_metrics_features = {}
        if itr is None:
            itr = 0
        model_features[itr] = {}
        model_metrics_features[itr] = {}

        #! Dynamic columns implementation
        #! required for Chain Regression
        if ct_transformers is None:
            ct_transformers = [
                ("", StandardScaler(), X_raw.columns)
            ]
        
        ct = ColumnTransformer(
            ct_transformers
        ).set_output(transform="pandas")

        metric_means = []
        #! Only MUltiOutput like algorithm is implemented
        for n, i in enumerate(y.columns):
            
            X_st = X_raw.copy()
            ct_st = clone(ct)
            X = ct_st.fit_transform(X_st)

            #! Hardcoded CV
            kfolds = model_selection.KFold(
                n_splits=4, 
                shuffle=True,
                random_state=n
            )
            #* populating of dict
            model_features[itr][i], model_metrics_features[itr][i] = self._stacking(
                X,
                y[i],
                cv=kfolds
            )
            model_features[itr][i]["ct"] = ct_st

            metric_means.append(list(model_metrics_features[itr][i].values()))
        
        model_metrics_features[itr]["means"] = {}
        for n, i in enumerate(model_metrics_features[itr][y.columns[0]].keys()):
             model_metrics_features[itr]["means"][i] = np.array(metric_means)[:, n].mean()
        
        print(model_features)
        return model_features, model_metrics_features
    
    def _multi_feature_stacking(self):
        return

    def _stacking(
        self,
        X,
        y,  #* one dimensional array
        cv,
        
    ):
        '''
        #* Stacking Implementation
        #* Method accepts X and y datasets
        #* X is n-dimensional, y is 1-dimensional array only
        #* X splits on k-number of folds
        #* Each fold uses for train / test and 
        #* considers as a new feature
        #* The number of new feature is n_folds * n_base_esimators
        #* New features appends to initial X
        #* to be used for meta model training
        #* All models used in training process stores to model dict
        #* for later unpacking and use on new / unseen data
        #* Parameters
        #* ----------
        #* X: Dataframe
        #*  Data to be used as predictors
        #* y : Dataframe
        #*  predictable
        #* cv : object
        #*  - cross validation object (KFold)
        #* Raises
        #* ----------
        #*
        #* Returns
        #* ----------
        #* model as a dict structure
        '''
        #* model structure
        #* iter level -> 0 : {} - upper lelvel
        #* feature level -> "7-6" : {}, "ct" : {} - upper level
        #* models level -> "bms" : {}, "meta" : {} 
        models = {}
        models["bms"] = {}
        models["meta"] = {}
        
        
        split = list(cv.split(X))

        X_base = X.copy()
        X_train_ = X.copy()
        bms_split = list(cv.split(X))


        meta_features = []
        for _, (ben, be) in enumerate(self.base_estimators):
            
            y_be_name = f"{ben}"
            X_base.loc[:, y_be_name] = np.full((len(X_base), ), np.nan)
            #! There is high risk of overfitting
            #! Number of first level features must be equal to len(self.base_estimators)
            #! Each fold is used to create portion of new feature
            for _, (train_b, test_b) in enumerate(bms_split):
                bec = clone(be)  #* copy to prevent overwriting
                #* k number of same feature
                # y_be_name = f"{ben}_{n}"
                # X_base.loc[:, y_be_name] = np.full((len(X_base), ), np.nan)
                # train_test_b = [*train_b, *test_b]
                #*

                bec.fit(
                    X_train_.loc[train_b, :],
                    y.loc[train_b]
                )
                
                X_base.loc[test_b, y_be_name] = bec.predict(
                    X_train_.loc[test_b, :]
                )
                models["bms"][y_be_name] = bec
                meta_features.append(y_be_name)
                    
                
        #* drop rows with NaN (ones that was not pupulated)
        X_base = X_base.dropna(axis=0)
        print(len(X_base), len(X))
        print(X_base)
        # X_meta = X_base.loc[:, meta_features]
        X_meta = X_base.copy()
        
        split_meta = list(cv.split(X_meta))
        X.loc[:, "y_pred"] = np.full((len(X), ), np.nan)
        
        for train, test in split_meta:
            meta = clone(self.meta_estimator)

            meta.fit(X_meta.loc[train, :], y.loc[train])
            X.loc[test, "y_pred"] = meta.predict(X_meta.loc[test, :])

            models["meta"] = meta

        X = X.dropna(axis=0)
        if len(X["y_pred"]) != len(y):
            raise ValueError("Some rows were not predicted")
        
        metrics = self.reg_metrics(
            y,
            X["y_pred"]
        )
        
        return models, metrics

    @staticmethod
    def predict(
        X,
        model: dict #! may be object or path to model
    ):
        '''
        #* It's dictionary (model) unpacking method
        #* Method accepts X dataset upon which predictions will be made
        #* and model (dict)
        #* It does iterate over levels in model:
        #*  Iteration level - number of created models
        #*  where each consist of base and meta models
        #*  Features level
        #*  Models level
        #* Parameters
        #* ----------
        #*
        #* Raises
        #* ----------
        #*
        #* Returns
        #* ----------
        #*
        '''
        #! MultiOutput Only
        #* Only for trained models -> It's actually unpacking method
        #* The level structure of model is same all the time:
        

        itr_res = {}
        for kitr,itr in model.items():
            feat_res = {}
            
            for kfeat, feat in itr.items():
                X_st =  feat["ct"].transform(X)
                X_base = X_st.copy()
                for kbms, bms in feat["bms"].items():
                    #* predicting and adding new features
                    X_base.loc[:, kbms] = bms.predict(X_st)
                    # print(kbms, bms)
                #* do smth with meta
                feat_res[kfeat] = feat["meta"].predict(X_base)
            itr_res[kitr] = pd.DataFrame(feat_res)
        
        if len(itr_res.keys()) > 1:
            df_concat = pd.concat(list(itr_res.values()), axis=0)
            res = df_concat.groupby(df_concat.index).mean()
            
            return res
                
        return itr_res[0]