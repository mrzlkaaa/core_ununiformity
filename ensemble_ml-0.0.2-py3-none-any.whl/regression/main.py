from . import *
from sklearn.metrics import (
    accuracy_score,
    log_loss,
    roc_auc_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

REG = [
    ("MAE", mean_absolute_error),
    ("MSE", mean_squared_error),
    ("R2", r2_score)
]


class Ensemble:
    def __init__(
        self,
        base_estimators,
        meta_estimator
    ):
        self.base_estimators = base_estimators
        self.meta_estimator = meta_estimator


    def class_metrics(
        self,
        y_true,
        y_pred
    ):
        return
    
    
    def reg_metrics(
        self,
        y_true,
        y_pred
    ):
        met = {}
        for (name, f) in REG:
            res =  f(
                y_true,
                y_pred
            )
            met[name] = res
            
            print(
                name,
                res
            )


        return met